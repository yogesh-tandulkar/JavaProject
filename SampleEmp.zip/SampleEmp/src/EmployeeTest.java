import java.lang.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Scanner;
import java.util.function.Predicate;

public class EmployeeTest  {
    public static void main(String[] args)throws Exception {

         ArrayList<EmployeeEducationDetails>list=new ArrayList<EmployeeEducationDetails>();
        list.add(new EmployeeEducationDetails(89,"22 march 2012","UG"));
        list.add(new EmployeeEducationDetails(80,"22 march 2012","UG"));
        list.add(new EmployeeEducationDetails(75,"27 march 2011","UG and PG"));
        list.add(new EmployeeEducationDetails(74,"27 march 2010","UG and PG"));

                ArrayList<Employee>list1=new ArrayList<Employee>();
        list1.add(new Employee("sam",39,"Devloper",3,list));
        list1.add(new Employee("yogita",43,"Tester",5,list));
        list1.add(new Employee("yogesh",33,"admin",4,list));
        list1.add(new Employee("sam",23,"Devloper",0,list));


ArrayList<OrganizationDetails>orglist=new ArrayList<OrganizationDetails>();
        orglist.add(new OrganizationDetails("Xoriant","Google",4,list1));
        orglist.add(new OrganizationDetails("Cybage","relaince",4,list1));
        orglist.add(new OrganizationDetails("TCS","pearson",4,list1));
        orglist.add(new OrganizationDetails("GlobalLogic","medtronic",4,list1));


for(int i=0;i<orglist.size();i++){
    OrganizationDetails org=orglist.get(i);
    System.out.println(org.previousOrg+" "+org.project+" "+org.duration+" ");
}






/*
OrganizationDetails org;
        Predicate<OrganizationDetails> p1= org -> .designation.equals("Developer");
        System.out.println("Displaying Employee Information who are Developer");

        OrganizationDetails.display(p1,orglist);



        Predicate<OrganizationDetails>p2=employee ->employee.exp>=2;
        //System.out.println("Displaying Employee Information who have an experience more than 2");
        //display(p2,list);

        System.out.println("Displaying Employee Information who do not have any experience in any organization");
        OrganizationDetails. display(p2.negate(),orglist);




        System.out.println("Displaying Employee Information who have an experience more than 2 and are Developer");
        OrganizationDetails. display(p1.and(p2),orglist);



*/

        // for ( int j=0; j<list.size(); j++ )
          //  System.out.println("Sr_No:"+j + list.get(j) );


        }
    }





        //print all employees who are developer
        //print all employee who are fresher
        //print all the employees who have Exp. more than 2yr and a developer/8/
