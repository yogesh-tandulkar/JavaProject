import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.function.Predicate;

public class Employee {
    private String mEmployeeName;
    private int age;
    protected String designation;
    protected int exp;
    private OrganizationDetails mOrganizationDetails;
    private List<EmployeeEducationDetails> eed;

    public Employee() {

    }

    public Employee(String name, int age, String designation, int exp, List<EmployeeEducationDetails> eed) {
        mEmployeeName = name;
        this.age = age;
        this.designation = designation;
        this.exp=exp;
        this.eed=eed;

    }
public List<EmployeeEducationDetails>getDetail(){
        return eed;
}







}
