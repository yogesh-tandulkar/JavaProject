import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

public class OrganizationDetails extends Employee{
    int fresher=1;
    int exp;
    String previousOrg ;
    String project;
    int duration;
    private List<Employee> emp;

    public OrganizationDetails(String previousOrg,String project,int duration,List<Employee>emp){
        this.previousOrg=previousOrg;
        this.project=project;
        this.duration=duration;
        this.emp=emp;
    }

    public static void display(Predicate<OrganizationDetails> p, ArrayList<OrganizationDetails> list){
        for(OrganizationDetails e:list){
            if(p.test(e)){
                System.out.println(e);

            }
            System.out.println("------------------------------------------------------------------------------");

        }
    }



    /*public void setpreviousOrg(){
        this.previousOrg=previousOrg;
    }
    public void setProject(){
        this.project=project;
    }
    public void setDuration(){
        this.duration=duration;
    }

    public String getName_of_Org(){
        return previousOrg;
    }
    public String getProject(){
        return project;
    }
    public int getDuration(){
        return duration;
    }
    */



}


