import java.util.ArrayList;
import java.util.Date;
import java.util.*;
import java.lang.*;
import java.util.Scanner;

public class EmployeeEducationDetails extends Employee {
    private int percent;
    String completiondate;
    String certification;
EmployeeEducationDetails ed;

    public EmployeeEducationDetails(int percent, String completiondate, String Degree) {
        this.percent = percent;
        this.completiondate = completiondate;
        this.certification = certification;
    }


   public void setPercent(int percent) {
       this.percent = percent;

   }


   // Scanner sc=new Scanner(System.in);  yet to be implement


   //This method can be dynamic
    public static void addEducationDetails(ArrayList<EmployeeEducationDetails>list){
        list.add(new EmployeeEducationDetails(89,"22 march 2012","UG"));
        list.add(new EmployeeEducationDetails(80,"22 march 2012","UG"));
        list.add(new EmployeeEducationDetails(75,"27 march 2011","UG and PG"));
        list.add(new EmployeeEducationDetails(74,"27 march 2010","UG and PG"));
        list.add(new EmployeeEducationDetails(72,"21 march 2017","UG "));
        list.add(new EmployeeEducationDetails(74,"27 march 2018","UG "));
        list.add(new EmployeeEducationDetails(76,"21 march 2017","UG "));
        list.add(new EmployeeEducationDetails(87,"27 march 2018","UG "));
        list.add(new EmployeeEducationDetails(81,"27 march 2018","UG"));


    }

}
